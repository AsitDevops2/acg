package com.jade.jira.model;

public class CreateIssueDTO {

}
