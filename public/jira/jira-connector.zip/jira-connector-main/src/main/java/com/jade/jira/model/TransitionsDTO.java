package com.jade.jira.model;

public class TransitionsDTO {
	

}
